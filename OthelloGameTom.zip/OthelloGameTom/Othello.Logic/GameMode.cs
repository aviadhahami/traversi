﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex06.Othello.Logic
{
    public enum GameMode
    {
        AgainstComputer
    }
}
