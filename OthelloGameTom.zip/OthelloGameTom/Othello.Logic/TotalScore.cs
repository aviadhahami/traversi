﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Othello.Logic
{
    public class PlayerAggregatedStatistcs
    {
        public int TotalWins { get; set; }
        public int TotalScore { get; set; }
    }
}
